<?php get_header(); ?>

<h1>Index</h1>

<?php get_footer(); ?>
