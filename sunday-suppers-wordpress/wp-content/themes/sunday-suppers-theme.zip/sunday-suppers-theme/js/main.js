



$('.nav-icon').click(function() {

  $('.mobile-overlay').css('height', '100%');
});

$('.closebtn').click( function () {

$('.mobile-overlay').css('height', '0%');

});
